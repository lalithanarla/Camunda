package com.example.workflow;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import javax.inject.Named;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

@Named
public class CalculateLateFee implements JavaDelegate {

	
    @Override
    public void execute(DelegateExecution execution) throws Exception {

    	SimpleDateFormat myFormat = new SimpleDateFormat("yyyy-MM-dd");
    	String processId = (String) execution.getVariable("pId");
    	String inputString1 = (String) execution.getVariableLocal("due_date");
    	String inputString2 = (String) execution.getVariable(processId +"-exp_date");
    	
    	System.out.println("due date: " +inputString1 + "pId: " +processId + "exp date: " +inputString2);
    	
    	long days = 0;
    	try {
    	    Date date1 = myFormat.parse(inputString1);
    	    Date date2 = myFormat.parse(inputString2);
    	    long diff = date2.getTime() - date1.getTime();
    	    days = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
    	    execution.setVariable("days", days);
    	    
    	} catch (ParseException e) {
    	    e.printStackTrace();
    	}   
    	
    	if(days<=3)
    		execution.setVariable("lateFee", 0);
    	else {
    		execution.setVariable("lateFee", days*1.20);
       	}
    	
    	//execution.setVariable("lateFee_amt", (long)(execution.getVariable("pymnt_amt")) + (long)(execution.getVariable("lateFee")));
    }
    
}

