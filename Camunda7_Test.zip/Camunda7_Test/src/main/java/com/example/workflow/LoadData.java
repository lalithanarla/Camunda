package com.example.workflow;

import java.util.List;

import javax.inject.Named;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.example.workflow.beans.Accounts;



@Named
public class LoadData implements JavaDelegate {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	 
    @Override
    public void execute(DelegateExecution execution) throws Exception {

    	        String sql = "SELECT * FROM LATE_FEE_ACCTS";
    	         
				
				  List<Accounts> customers = jdbcTemplate.query(sql,
				  BeanPropertyRowMapper.newInstance(Accounts.class));
				  
				  execution.setVariable("customers", customers); 
				  //execution.getProcessInstanceId();
    	        
    	        /*for(Accounts acct : accts) {
    	        	
    	        	String text = "Dear "+acct.getFirst_name()+"!"+"\n\n"+
    	    	        	"This is a friendly reminder that we haven’t received payment of Rs."+acct.getPaymnt_amt()+
    	    	        	" which was due on " +acct.getPaymnt_date()+". We’re not aware of any outstanding issues or reasons for non-payment, so we would like to respectfully ask you to make payment as soon as possible. Please visit Citi Bank portal for providing your reasons and request to waive off late fee charges."+"\n\n"+"Kind regards,"+"\n"+"Citi Bank";
    	        	
    	        	execution.setVariable("text", text); 
					execution.setVariable("to", acct.getEmail());
					execution.setVariable("due_date", acct.getPaymnt_date());
					execution.setVariable("pymnt_amt", acct.getPaymnt_amt());
					execution.setVariable("crdt_scr", acct.getCredit_score());
    	       
    	        */
    	        
					/*
					 * Accounts mail = new Accounts();
					 * 
					 * mail.setMail_body(text); mail.setEmail(acct.getEmail());
					 * 
					 * mails.add(mail);
					 */
    	        	
    	        }	
    	        
    	        /*  ObjectValue mailValues = Variables.objectValue(mails)
    	          .serializationDataFormat(Variables.SerializationDataFormats.JAVA)
    	          .create();

    	        execution.setVariable("someVariable", mailValues);
    	        
    	        System.out.println("printing values:" +mailValues);
    	        	
    	        for(Accounts mail : mails) {
    	        	
    	        	VariableMap variables =
    	        			  Variables.createVariables()
    	        			  .putValueTyped("text", Variables.stringValue(mail.getMail_body()))
    	        			  .putValueTyped("mail_id", Variables.stringValue(mail.getEmail()));
    	        			  
    	        			runtimeService.setVariablesLocal(execution.getId(), "order", variables);
    	        	*/
    	        	
					
					  
					 
    	        			
    	        }
    	        

    



