package com.example.workflow.controller;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.camunda.bpm.engine.HistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ServerWebExchange;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.camunda.zeebe.client.api.response.ProcessInstanceResult;
import io.camunda.zeebe.spring.client.lifecycle.ZeebeClientLifecycle;

@RestController
public class PaymentProcessingController {
	
	//private static Logger log = LoggerFactory.getLogger(PaymentProcessingController.class);

	/*
	 * @Autowired private ZeebeClient client;
	 */
	  
	  @Autowired
	  private ZeebeClientLifecycle client;
	  
	  @Autowired
	  ObjectMapper mapper; 
	  
	  protected HistoryService historyService;

	  @PostMapping("/processPayment")
	  public ResponseEntity<String> processPayment(ServerWebExchange exchange) throws InterruptedException, ExecutionException, JsonMappingException, JsonProcessingException {
		  //payment-processing
		  //RestAPITest
		  
		  System.out.println("Client running ?? :" +client.isRunning());
		  
		  final ProcessInstanceResult processInstanceResult =
		    	    client
		    	        .newCreateInstanceCommand()
		    	        .bpmnProcessId("payment-processing")
		    	        .latestVersion()
		    	        .withResult() // to await the completion of process execution and return result
		    	        .send()
		    	        .join();

		  
		  		TypeReference<List<Object>> listTypeRef = new TypeReference<List<Object>>() {};
		  		
		  		TypeReference<Map<String, Object>> mapTypeRef = new TypeReference<Map<String, Object>>() {};
		  
		  		List<Object> opList = mapper.convertValue(processInstanceResult.getVariablesAsMap().get("accounts"), listTypeRef);
		    	
		    	Map<String, Object> map = mapper.convertValue(opList.get(0), mapTypeRef);
		        System.out.println(opList.get(0));
		        System.out.println(opList.get(1));
		        System.out.println(map.get("pymnt_amt"));
		    	
	
		        return ResponseEntity.ok(processInstanceResult.getVariables());
	  }

		
}
