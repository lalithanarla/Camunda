package com.example.workflow;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Component;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.JobWorker;

@Component
public class CalculateLateFee {

	
    @JobWorker(type="calculate")
    public void calculateFee(final JobClient client, final ActivatedJob job) {

    	SimpleDateFormat myFormat = new SimpleDateFormat("yyyy-MM-dd");
    	Map<String, Object> inputVars= job.getVariablesAsMap();
    	Map<String, Object> outputVars = new HashMap<String, Object>();		
    	String inputString1 = (String) inputVars.get("due_date");
    	String inputString2 = (String) inputVars.get("exp_date");
    	long days = 0;
    	try {
    	    Date date1 = myFormat.parse(inputString1);
    	    Date date2 = myFormat.parse(inputString2);
    	    long diff = date2.getTime() - date1.getTime();
    	    days = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
    	    outputVars.put("days", days);
    	    
    	} catch (ParseException e) {
    	    e.printStackTrace();
    	}   
    	
    	if(days<=3)
    		outputVars.put("lateFee", 0);
    	else {
    		outputVars.put("lateFee", days*1.20);
       	}
    	
		client.newCompleteCommand(job.getKey()).variables(outputVars).send().exceptionally((throwable)->{
			throw new RuntimeException("Couldn't complete job" +job, throwable);
    	
		});
    }
}
