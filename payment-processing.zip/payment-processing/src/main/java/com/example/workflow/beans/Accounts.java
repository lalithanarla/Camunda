package com.example.workflow.beans;

import org.springframework.stereotype.Component;

@Component
public class Accounts {
	
	
	public String acct_id;
	public String first_name;
	public String last_name;
	public String email;
	public String acct_number;
	public String paymnt_date;
	public String paymnt_amt;
	public String mail_body;
	public String cust_type;
	public String getCust_type() {
		return cust_type;
	}
	public void setCust_type(String cust_type) {
		this.cust_type = cust_type;
	}
	public Integer credit_score;
	public String getAcct_id() {
		return acct_id;
	}
	public void setAcct_id(String acct_id) {
		this.acct_id = acct_id;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAcct_number() {
		return acct_number;
	}
	public void setAcct_number(String acct_number) {
		this.acct_number = acct_number;
	}
	public String getPaymnt_date() {
		return paymnt_date;
	}
	public void setPaymnt_date(String paymnt_date) {
		this.paymnt_date = paymnt_date;
	}
	public String getPaymnt_amt() {
		return paymnt_amt;
	}
	public void setPaymnt_amt(String paymnt_amt) {
		this.paymnt_amt = paymnt_amt;
	}
	public String getMail_body() {
		return mail_body;
	}
	public void setMail_body(String mail_body) {
		this.mail_body = mail_body;
	}
	public Integer getCredit_score() {
		return credit_score;
	}
	public void setCredit_score(Integer credit_score) {
		this.credit_score = credit_score;
	}
	@Override
	public String toString() {
		return "Accounts [acct_id=" + acct_id + ", first_name=" + first_name + ", last_name=" + last_name + ", email="
				+ email + ", acct_number=" + acct_number + ", paymnt_date=" + paymnt_date + ", paymnt_amt=" + paymnt_amt
				+ ", mail_body=" + mail_body + ", credit_score=" + credit_score + "]";
	}
	
	
	
}
