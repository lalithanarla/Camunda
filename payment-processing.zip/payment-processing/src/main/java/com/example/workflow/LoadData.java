package com.example.workflow;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.example.workflow.beans.Accounts;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.JobWorker;




@Component
public class LoadData {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	 
	 @JobWorker(type="load") // type is set to method name: "load".
	  public void loader(final JobClient client, final ActivatedJob job) {
	    
		 
		 List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		 Map<String, Object> resultMapList = new HashMap<String, Object>();
	    
    	        String sql = "SELECT * FROM LATE_FEE_ACCTS";
    	         
				
				  List<Accounts> accts = jdbcTemplate.query(sql,
				  BeanPropertyRowMapper.newInstance(Accounts.class));
				  Map<String, Object> resultMap = new HashMap<String, Object>(); 
    	        
    	        for(Accounts acct : accts) {
    	        	//Map<String, Object> resultMap = new HashMap<String, Object>();
    	        	String text = "Dear "+acct.getFirst_name()+"!"+"\n\n"+
    	    	        	"This is a friendly reminder that we haven’t received payment of Rs."+acct.getPaymnt_amt()+
    	    	        	" which was due on " +acct.getPaymnt_date()+". We’re not aware of any outstanding issues or reasons for non-payment, so we would like to respectfully ask you to make payment as soon as possible. Please visit Citi Bank portal for providing your reasons and request to waive off late fee charges."+"\n\n"+"Kind regards,"+"\n"+"Citi Bank";
    	        	
    	        	    	        	
    	        	resultMap.put("text", text); 
					resultMap.put("to", acct.getEmail());
					resultMap.put("due_date", acct.getPaymnt_date());
					resultMap.put("pymnt_amt", acct.getPaymnt_amt());
					resultMap.put("crdt_scr", acct.getCredit_score());
					resultMap.put("cust_type", acct.getCust_type());
					
					list.add(resultMap);
    	          	        	
					
    	        }	
    	        
    	        resultMapList.put("accounts",list);
    	        
    	        client.newCompleteCommand(job.getKey()).variables(resultMap).send().exceptionally((throwable)->{
					throw new RuntimeException("Couldn't complete job" +job, throwable);
				});
				
    	  }
    	        
}    	    
    



