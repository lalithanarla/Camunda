package com.example.workflowMI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.camunda.zeebe.spring.client.EnableZeebeClient;
import io.camunda.zeebe.spring.client.annotation.Deployment;


@SpringBootApplication
@EnableZeebeClient
//@Deployment(resources = "classpath:payment_processing-multiinstance.bpmn")
public class PaymentProcessingApplicationMI {
	
  public static void main(String... args) {
    SpringApplication.run(PaymentProcessingApplicationMI.class, args);
  }
    
}