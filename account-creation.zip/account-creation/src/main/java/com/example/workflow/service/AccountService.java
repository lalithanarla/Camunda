package com.example.workflow.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.workflow.beans.Customer;
import com.example.workflow.beans.CustomerRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.JobWorker;

@Service
public class AccountService {
	
	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	AccountNumberGenerator accountNumberGenerator;
	
	@Autowired
	ObjectMapper mapper;
    
	private Customer obj;
	
    @JobWorker(type = "createNewAccount")
    public void createNew(final JobClient client, final ActivatedJob job) {
        
    	Long acct_Num= AccountNumberGenerator.getAcctNum();
    	Integer custId= accountNumberGenerator.getCustId();
		       
    	//Map<String,Object> customer= job.getVariablesAsMap();
    	Customer customer = job.getVariablesAsType(Customer.class);
    	
    	obj = createAccount(customer,acct_Num.toString(),custId.toString());
    	
    	client.newCompleteCommand(job.getKey()).variables(obj).send().exceptionally((throwable)->{
			throw new RuntimeException("Couldn't complete job" +job, throwable);
		});
    	           
    }
    
    @JobWorker(type = "fetchCustomerId")
    public void fetchCustomerId(final JobClient client, final ActivatedJob job) {
    
    	String custId;
    	Customer customer = job.getVariablesAsType(Customer.class);
    	
    	List<Customer> cust = customerRepository.findByFirstNameAndMobile(customer.getFirstName(), customer.getMobile());
        
    	if(!(cust.isEmpty()) && cust!=null) {
    		custId = cust.get(0).getCustId();
    	}
    	else
    		custId = null;
        
    	Map<String,String> var = new HashMap<String,String>();
        
        var.put("custId", custId);
        
        client.newCompleteCommand(job.getKey()).variables(var).send().exceptionally((throwable)->{
			throw new RuntimeException("Couldn't complete job" +job, throwable);
		});
    	
       
    }
    
    
    @JobWorker(type = "createChildAccount")
    public void createChild(final JobClient client, final ActivatedJob job) {
    
    try {    
    	Long acct_Num= AccountNumberGenerator.getAcctNum();
    	       
    	//Map<String,Object> customer= job.getVariablesAsMap();
    	Customer customer = job.getVariablesAsType(Customer.class);
    	
    	obj=createAccount(customer,acct_Num.toString(),customer.getCustId());
        
        
        client.newCompleteCommand(job.getKey()).variables(obj).send().exceptionally((throwable)->{
			throw new RuntimeException("Couldn't complete job" +job, throwable);
		});
    	}
        catch (Exception ex) {
        	System.out.println("Entered Catch block");
        	client.newThrowErrorCommand(job)
        	   .errorCode("IndexOutOfBound_Error")
        	   .errorMessage("IndexOutOfBound_Error")
        	   .send()
        	   .exceptionally(t -> {throw new RuntimeException("Could not throw BPMN error: " + t.getMessage(), t);});}
            
    }
    
    public Customer createAccount(Customer customer, String acct_Num, String cust_Id) {
    	
    	obj = new Customer(cust_Id,acct_Num,customer.getAddress(),
		           customer.getExistingCust(),customer.getFirstName(),
		           customer.getLastName(),customer.getMail(),customer.getMobile()); 
    	
    	customerRepository.save(obj);
    	
    	return obj;
    }

    @JobWorker(type = "getAccounts")
    public void getAccounts(final JobClient client, final ActivatedJob job) {
       
    try {
    	String custId= job.getVariablesAsType(Customer.class).getCustId();
    	
    	List<Customer> cust = customerRepository.findByCustId(custId);
    	    	
    	Map<String,Object> custList= new HashMap<String,Object>();
    	custList.put("list", cust);
    	
        client.newCompleteCommand(job.getKey()).variables(custList).send().exceptionally((throwable)->{
			throw new RuntimeException("Couldn't complete job" +job, throwable);
		});
    }
    catch (Exception ex) {
    	client.newFailCommand(job)
          .retries(job.getRetries()-1) // <1>: Decrement retries
          .errorMessage("Could not retrieve AccountDetails due to: " + ex.getMessage()) // <2>
          .send()
          .exceptionally(t -> {throw new RuntimeException("Could not fail job: " + t.getMessage(), t);});
    }
            
    }
    
}