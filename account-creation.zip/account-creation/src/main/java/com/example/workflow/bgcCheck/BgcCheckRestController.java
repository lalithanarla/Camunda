package com.example.workflow.bgcCheck;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class BgcCheckRestController {

    private Logger logger = LoggerFactory.getLogger(BgcCheckRestController.class);

    @GetMapping("/check")
    public ResponseEntity<String> verifyCustomer() {
        logger.info("BGC REST API called");
        return ResponseEntity.status(HttpStatus.OK).build();
    }

}