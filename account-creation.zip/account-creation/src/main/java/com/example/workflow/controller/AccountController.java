package com.example.workflow.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.workflow.beans.Customer;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.camunda.zeebe.client.api.response.ProcessInstanceEvent;
import io.camunda.zeebe.client.api.response.ProcessInstanceResult;
import io.camunda.zeebe.spring.client.lifecycle.ZeebeClientLifecycle;

@RestController
public class AccountController {
    
    @Autowired
	private ZeebeClientLifecycle client;
        
    @Autowired
	ObjectMapper mapper;
    
    @PostMapping("api/v1/accounts/create")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<String> create(@RequestBody Customer customer) throws JsonProcessingException {
    	 
    	customer.setRequestType("Create");
    	
    	HttpHeaders responseHeaders = new HttpHeaders();
       
    	final ProcessInstanceResult processInstanceResult =
		    	    client
		    	        .newCreateInstanceCommand()
		    	        .bpmnProcessId("AccountManagement_Headless")
		    	        .latestVersion()
		    	        .variables(customer)
		    	        .withResult() // to await the completion of process execution and return result
		    	        .send()
		    	        .join();
    	
    	long pid = processInstanceResult.getProcessInstanceKey();
    	
    	responseHeaders.set("Pid", pid+"");
    	
    	Map<String,Object> responseBody= new HashMap<String,Object>();
    			
    	responseBody.put("CustomerId",processInstanceResult.getVariablesAsMap().get("custId"));
    	responseBody.put("AccountNumber",processInstanceResult.getVariablesAsMap().get("acctNum"));
    	
    	System.out.println("Error:" +processInstanceResult.getVariablesAsMap().get("Error"));
    	
    	return ResponseEntity.ok()
    			.headers(responseHeaders)
    			.body(mapper.writeValueAsString(responseBody));
    } 
    
    @GetMapping("api/v1/accounts/getAccounts/{customerId}")
    public ResponseEntity<String> checkStatus(@PathVariable String customerId) throws JsonProcessingException {
    	
    	Map<String,Object> request= new HashMap<String,Object>();
    	request.put("custId", customerId);
    	request.put("requestType", "Check");
    	
    	final ProcessInstanceResult processInstanceResult =
		    	    client
		    	        .newCreateInstanceCommand()
		    	        .bpmnProcessId("AccountManagement_Headless")
		    	        .latestVersion()
		    	        .variables(request)
		    	        .withResult() // to await the completion of process execution and return result
		    	        .send()
		    	        .join();
    	
		return ResponseEntity.ok(processInstanceResult.getVariablesAsMap().get("list").toString());
    } 

}