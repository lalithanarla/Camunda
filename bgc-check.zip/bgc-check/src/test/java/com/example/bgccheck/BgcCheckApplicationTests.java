package com.example.bgccheck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BgcCheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
